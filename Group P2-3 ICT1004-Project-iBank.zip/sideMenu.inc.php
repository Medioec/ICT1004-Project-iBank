
<div class="user-side-menu">
    <div class="side-menu-title"><h3>Links</h3></div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link" href="accounts_view.php">View accounts</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="accounts_create.php">Create account</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="transfer_to_own.php">Transfer to own account</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="transfer_to_other.php">Transfer to other account</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="view_transaction.php">View transaction history</a>
        </li>
    </ul>
</div>
