# ICT1004-Project-iBank
banking website for ICT1004

Requirements:
phpmailer installed with composer
phpmailer/vendor folder at /var/www/phpmailer/vendor
db-config.ini at /var/www/private/db-config.ini

Sql safemode set to off for bank account deletion
SET SQL_SAFE_UPDATES = 0;