<footer class="container-fluid">
    <div class="footer">
        <p class="copyright">Copyright &copy; 2021 Double'O4 Bank</p>
    </div>
</footer>